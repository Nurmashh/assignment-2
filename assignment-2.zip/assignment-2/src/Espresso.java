// Шаг 2: Создайте конкретные классы кофе
public class Espresso extends Coffee {
    public Espresso() {
        description = "Эспрессо";
    }

    public double cost() {
        return 4;
    }
}