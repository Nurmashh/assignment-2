public class MilkDecorator extends CoffeeDecorator {
    public MilkDecorator(Coffee coffee) {
        super(coffee);
    }

    public String getDescription() {
        return coffee.getDescription() + ", с молоком";
    }

    public double cost() {
        return coffee.cost() + 0.5;
    }
}