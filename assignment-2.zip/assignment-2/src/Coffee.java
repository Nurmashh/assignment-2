// Шаг 1: Создайте базовый класс Coffee
public abstract class Coffee {
    protected String description;

    public String getDescription() {
        return description;
    }

    public abstract double cost();
}