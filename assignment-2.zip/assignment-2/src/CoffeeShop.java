import java.util.Scanner;

public class CoffeeShop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        Coffee coffee = null;

        while (true) {
            System.out.println("Выберите кофейный продукт (1 - Эспрессо, 2 - Латте, 3 - Американо):");
            int choice = scanner.nextInt();

            if (choice == 1) {
                coffee = new Espresso();
                break;
            } else if (choice == 2) {
                coffee = new Latte();
                break;
            } else if (choice == 3) {
                coffee = new Americano();
                break;
            } else {
                System.out.println("Неверный выбор. Пожалуйста, выберите снова.");
            }
        }

        System.out.println("Хотите добавить молоко? (1 - Да, 2 - Нет):");
        int milkChoice = scanner.nextInt();

        if (milkChoice == 1) {
            coffee = new MilkDecorator(coffee);
        }

        System.out.println("Хотите добавить сахар? (1 - Да, 2 - Нет):");
        int sugarChoice = scanner.nextInt();

        if (sugarChoice == 1) {
            coffee = new SugarDecorator(coffee);
        }

        System.out.println("Хотите добавить карамель? (1 - Да, 2 - Нет):");
        int caramelChoice = scanner.nextInt();

        if (caramelChoice == 1) {
            coffee = new CaramelDecorator(coffee);
        }

        System.out.println("Ваш заказ: " + coffee.getDescription());
        System.out.println("Стоимость: $" + coffee.cost());

        scanner.close();
    }
}
