public class Americano extends Coffee {
    public Americano() {
        description = "Американо";
    }

    public double cost() {
        return 4;
    }
}