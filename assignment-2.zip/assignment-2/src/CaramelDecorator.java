public class CaramelDecorator extends CoffeeDecorator {
    public CaramelDecorator(Coffee coffee) {
        super(coffee);
    }

    public String getDescription() {
        return coffee.getDescription() + ", с карамелью";
    }

    public double cost() {
        return coffee.cost() + 0.75;
    }
}
