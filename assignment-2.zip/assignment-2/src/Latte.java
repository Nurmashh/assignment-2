public class Latte extends Coffee {
    public Latte() {
        description = "Латте";
    }

    public double cost() {
        return 4;
    }
}